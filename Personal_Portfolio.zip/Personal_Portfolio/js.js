
document.addEventListener("DOMContentLoaded", function () {
    const banner = document.getElementById("cookie-consent");
    const accepted = localStorage.getItem("cookieConsent");

    if (!accepted) {
        banner.style.display = "block";
    }

    document.getElementById("accept-cookies").addEventListener("click", function () {
        localStorage.setItem("cookieConsent", "accepted");
        banner.style.display = "none";
        // Optional: Initialize analytics, ads, etc.
    });

    document.getElementById("reject-cookies").addEventListener("click", function () {
        localStorage.setItem("cookieConsent", "rejected");
        banner.style.display = "none";
        // Optional: Disable or prevent analytics, ads, etc.
    });
});

